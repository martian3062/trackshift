# n8n Automation for Mobility Simulator

This folder contains an n8n workflow that:

- Receives leaderboard updates from the Django backend via HTTP POST
- Calls the Groq chat completion API to summarise the update
- Sends the summary to Slack

## Steps

1. Import `workflows/leaderboard_notification.json` into your n8n instance.
2. Set environment variables:
   - `GROQ_API_KEY` in n8n
3. Configure the **Slack API** credentials in n8n.
4. In Django, send a POST request to the n8n HTTP Trigger URL whenever the leaderboard changes.
