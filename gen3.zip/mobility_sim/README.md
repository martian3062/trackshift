# Competitive Mobility Simulator (Django + React + n8n + Groq)

This is a starter skeleton for your competitive mobility systems simulator.

- `backend/` – Django + DRF + Channels API
- `frontend/` – React UI (Webpack + Babel)
- `n8n/` – Example automation workflow integrating Groq and Slack

## Quickstart (Backend)

```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

## Quickstart (Frontend)

```bash
cd frontend
npm install
npm start
```

## n8n + Groq

- Add your `GROQ_API_KEY` in both Django env and n8n env.
- Import the workflow in `n8n/workflows/leaderboard_notification.json`.
