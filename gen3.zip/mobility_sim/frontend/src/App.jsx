import React from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import SimulatorPage from "./pages/SimulatorPage";
import DashboardPage from "./pages/DashboardPage";

export default function App() {
  return (
    <BrowserRouter>
      <div style={{ display: "flex", minHeight: "100vh" }}>
        <nav style={{ width: 240, padding: 16, borderRight: "1px solid #ddd" }}>
          <h2>Mobility Simulator</h2>
          <ul style={{ listStyle: "none", padding: 0 }}>
            <li><Link to="/">Dashboard</Link></li>
            <li><Link to="/simulator">Simulator</Link></li>
          </ul>
        </nav>
        <main style={{ flex: 1, padding: 24 }}>
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/simulator" element={<SimulatorPage />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}
