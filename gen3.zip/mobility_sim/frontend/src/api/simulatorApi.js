import client from "./client";

export function listRuns() {
    return client.request("/api/sim/runs/");
}

export function createRun(data) {
    return client.request("/api/sim/runs/", {
        method: "POST",
        body: JSON.stringify(data)
    });
}

export function tickRun(id) {
    return client.request(`/api/sim/runs/${id}/tick/`, {
        method: "POST"
    });
}
