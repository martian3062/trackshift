import client from "./client";

export function fetchLeaderboard() {
    return client.request("/api/leaderboard/entries/");
}
