import React, { useState, useEffect } from "react";
import { listRuns, createRun, tickRun } from "../api/simulatorApi";

export default function SimulatorPage() {
  const [runs, setRuns] = useState([]);
  const [selected, setSelected] = useState(null);

  const refresh = () => {
    listRuns().then(data => {
      setRuns(data);
      if (!selected && data.length) setSelected(data[0]);
    }).catch(console.error);
  };

  useEffect(() => {
    refresh();
  }, []);

  const handleCreate = async () => {
    await createRun({ name: "New Simulation" });
    refresh();
  };

  const handleTick = async () => {
    if (!selected) return;
    const updated = await tickRun(selected.id);
    setSelected(updated);
  };

  return (
    <div>
      <h1>Simulator</h1>
      <button onClick={handleCreate}>Create Simulation</button>
      <button onClick={handleTick} disabled={!selected} style={{ marginLeft: 8 }}>
        Tick Selected
      </button>

      <h2>Simulations</h2>
      <ul>
        {runs.map(run => (
          <li key={run.id}>
            <button onClick={() => setSelected(run)}>
              {run.name} ({run.agents.length} agents)
            </button>
          </li>
        ))}
      </ul>

      {selected && (
        <>
          <h2>Selected: {selected.name}</h2>
          <pre>{JSON.stringify(selected, null, 2)}</pre>
        </>
      )}
    </div>
  );
}
