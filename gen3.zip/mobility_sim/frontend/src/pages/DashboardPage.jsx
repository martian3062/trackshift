import React, { useEffect, useState } from "react";
import { fetchLeaderboard } from "../api/leaderboardApi";

export default function DashboardPage() {
  const [entries, setEntries] = useState([]);

  useEffect(() => {
    fetchLeaderboard().then(setEntries).catch(console.error);
  }, []);

  return (
    <div>
      <h1>Dashboard</h1>
      <h2>Leaderboard</h2>
      <table>
        <thead>
          <tr>
            <th>Rank</th>
            <th>Agent</th>
            <th>Score</th>
          </tr>
        </thead>
        <tbody>
          {entries.map(e => (
            <tr key={e.id}>
              <td>{e.rank}</td>
              <td>{e.agent}</td>
              <td>{e.score}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
