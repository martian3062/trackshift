from rest_framework import serializers
from .models import LeaderboardEntry, Policy

class PolicySerializer(serializers.ModelSerializer):
    class Meta:
        model = Policy
        fields = "__all__"

class LeaderboardEntrySerializer(serializers.ModelSerializer):
    policy = PolicySerializer(read_only=True)

    class Meta:
        model = LeaderboardEntry
        fields = "__all__"
