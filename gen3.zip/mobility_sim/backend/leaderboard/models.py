from django.db import models
from simulator.models import SimulationRun, Agent

class Policy(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.name

class LeaderboardEntry(models.Model):
    simulation = models.ForeignKey(SimulationRun, on_delete=models.CASCADE)
    agent = models.ForeignKey(Agent, on_delete=models.CASCADE)
    policy = models.ForeignKey(Policy, null=True, blank=True, on_delete=models.SET_NULL)
    score = models.FloatField(default=0.0)
    rank = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.agent} -> {self.score}"
