from rest_framework import viewsets
from .models import LeaderboardEntry, Policy
from .serializers import LeaderboardEntrySerializer, PolicySerializer

class PolicyViewSet(viewsets.ModelViewSet):
    queryset = Policy.objects.all()
    serializer_class = PolicySerializer

class LeaderboardEntryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = LeaderboardEntry.objects.order_by("rank", "-score")
    serializer_class = LeaderboardEntrySerializer
