from rest_framework.routers import DefaultRouter
from .views import PolicyViewSet, LeaderboardEntryViewSet

router = DefaultRouter()
router.register(r"policies", PolicyViewSet, basename="policy")
router.register(r"entries", LeaderboardEntryViewSet, basename="entry")

urlpatterns = router.urls
