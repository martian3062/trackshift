from rest_framework import serializers
from .models import SimulationRun, Agent, Event

class AgentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Agent
        fields = "__all__"

class EventSerializer(serializers.ModelSerializer):
    class Meta:
        model = Event
        fields = "__all__"

class SimulationRunSerializer(serializers.ModelSerializer):
    agents = AgentSerializer(many=True, read_only=True)
    events = EventSerializer(many=True, read_only=True)

    class Meta:
        model = SimulationRun
        fields = "__all__"
