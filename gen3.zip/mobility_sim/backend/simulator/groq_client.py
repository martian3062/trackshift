import os
import requests

GROQ_API_KEY = os.getenv("GROQ_API_KEY")

def explain_event_with_groq(event):
    """Call Groq API to generate a natural language explanation of an event.

    This is a simple placeholder that you can expand.
    """
    if not GROQ_API_KEY:
        return "Groq API key not configured."

    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": "mixtral-8x7b-32768",
        "messages": [
            {
                "role": "system",
                "content": "You are an assistant that explains mobility simulation events briefly."
            },
            {
                "role": "user",
                "content": f"Explain this event in one sentence: {event.type} - {event.description}"
            },
        ],
        "max_tokens": 80,
    }
    resp = requests.post(url, headers=headers, json=payload, timeout=20)
    resp.raise_for_status()
    data = resp.json()
    return data["choices"][0]["message"]["content"].strip()
