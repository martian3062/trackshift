from rest_framework.routers import DefaultRouter
from .views import SimulationRunViewSet, AgentViewSet, EventViewSet

router = DefaultRouter()
router.register(r"runs", SimulationRunViewSet, basename="run")
router.register(r"agents", AgentViewSet, basename="agent")
router.register(r"events", EventViewSet, basename="event")

urlpatterns = router.urls
