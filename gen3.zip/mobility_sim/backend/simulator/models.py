from django.db import models

class SimulationRun(models.Model):
    name = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name

class Agent(models.Model):
    simulation = models.ForeignKey(SimulationRun, related_name="agents", on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    x = models.FloatField(default=0.0)
    y = models.FloatField(default=0.0)
    speed = models.FloatField(default=0.0)
    team = models.CharField(max_length=50, blank=True)

    def __str__(self):
        return f"{self.name} ({self.simulation_id})"

class Event(models.Model):
    simulation = models.ForeignKey(SimulationRun, related_name="events", on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    agent = models.ForeignKey(Agent, null=True, blank=True, on_delete=models.SET_NULL)
    type = models.CharField(max_length=50)
    description = models.TextField(blank=True)

    def __str__(self):
        return f"{self.type} @ {self.timestamp}"
