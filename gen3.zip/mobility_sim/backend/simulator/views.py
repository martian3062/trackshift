from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import SimulationRun, Agent, Event
from .serializers import SimulationRunSerializer, AgentSerializer, EventSerializer
from .services.engine import tick_simulation

class SimulationRunViewSet(viewsets.ModelViewSet):
    queryset = SimulationRun.objects.all().order_by("-created_at")
    serializer_class = SimulationRunSerializer

    @action(detail=True, methods=["post"])
    def tick(self, request, pk=None):
        tick_simulation(pk)
        sim = self.get_object()
        serializer = self.get_serializer(sim)
        return Response(serializer.data)

class AgentViewSet(viewsets.ModelViewSet):
    queryset = Agent.objects.all()
    serializer_class = AgentSerializer

class EventViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Event.objects.all().order_by("-timestamp")
    serializer_class = EventSerializer
