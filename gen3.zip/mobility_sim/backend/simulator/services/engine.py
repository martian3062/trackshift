import random
from .models import SimulationRun, Agent, Event
from .groq_client import explain_event_with_groq

def tick_simulation(sim_id: int):
    sim = SimulationRun.objects.get(id=sim_id)
    agents = list(sim.agents.all())

    for agent in agents:
        agent.x += agent.speed
        agent.save()

        # randomly create an event
        if random.random() < 0.1:
            evt = Event.objects.create(
                simulation=sim,
                agent=agent,
                type="RANDOM_BURST",
                description=f"{agent.name} accelerated unexpectedly.",
            )
            # optional Groq explanation for logging / n8n
            try:
                evt.description += "\nAI: " + explain_event_with_groq(evt)
                evt.save()
            except Exception:
                pass

    return sim
