from django.urls import path
from simulator import consumers

websocket_urlpatterns = [
    path("ws/sim/<str:sim_id>/", consumers.SimulationConsumer.as_asgi()),
]
